import React from 'react';

export default function About() {
	return (
		<div className="text-center">
			<h1>About</h1>
			<p>This is todo list app version 1.0.0</p>
		</div>
	)
}